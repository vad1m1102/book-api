package com.example.bool_api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BoolApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
